# Get Your Keys — Step by Step
## Cognizant Hackathon Azure Environment

Open Azure Portal → your resource group → follow each step below.

---

### 1. Azure OpenAI Key + Endpoint
**Resource:** `Azure-OpenAI-eventgenius` (East US)
```
Portal → Azure-OpenAI-eventgenius → Keys and Endpoint
  AZURE_OPENAI_ENDPOINT = Endpoint  (e.g. https://Azure-OpenAI-eventgenius.openai.azure.com/)
  AZURE_OPENAI_KEY      = KEY 1

Portal → Azure-OpenAI-eventgenius → Model Deployments
  AZURE_OPENAI_DEPLOYMENT = (copy exact deployment name, e.g. "gpt-4o" or "gpt-4o-eventgenius")
```

---

### 2. Bing Search Key
**Resource:** `BingSearch-enventgenius` (Global)
```
Portal → BingSearch-enventgenius → Keys and Endpoint
  BING_SEARCH_KEY = KEY 1
```

---

### 3. Communication Services Connection String
**Resource:** `azure-Eventgenius` (Global)
```
Portal → azure-Eventgenius → Settings → Keys
  AZURE_COMM_CONNECTION_STRING = Connection string (the long one starting with "endpoint=...")
```

---

### 4. Sender Email Address
**Resource:** `azureemail-eventgenius` + `AzureManagedDomain`
```
Portal → azureemail-eventgenius → Provision domains → AzureManagedDomain
  → MailFrom addresses → copy the DoNotReply address
  SENDER_EMAIL = DoNotReply@xxxxxxxx.azurecomm.net
```

---

### 5. Function App URL + Key (Trade-off Engine)
**Resource:** `tradeoffengine` (South India)
```
Portal → tradeoffengine → Functions → (click your function name)
  → Get Function URL → copy
  TRADEOFF_FUNCTION_URL = https://tradeoffengine.azurewebsites.net/api/...
  TRADEOFF_FUNCTION_KEY = (from the same dialog, "Function" key)
```

---

### Fill in .env file

Copy `backend/.env.example` to `backend/.env` and paste all values:

```bash
cp backend/.env.example backend/.env
# Open .env and fill in each value
```

---

### Run Locally (test before deploying)

```bash
cd backend
npm install
npm run dev
# Open http://localhost:8080/health — should show all 5 resources listed
```

---

### Deploy to Azure

```bash
chmod +x scripts/deploy.sh
./scripts/deploy.sh
# Script will prompt for each key and deploy everything
```
